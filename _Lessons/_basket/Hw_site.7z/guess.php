<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="style.css">
	</head>
<body>
<div class="content">
	<?php 
		include "menu.php";
	?>
	
	<div class="contentWrap">
		<div class="content">
			<div class="center">

				<h1>Игра в угадайку</h1>

				<div class ="box">
					<?php
						$answer = rand(0,100);
						if (isset($_GET["userAnswer1"]) && isset($_GET["userAnswer2"])) {
							if ($answer == $_GET["userAnswer1"]) {
								echo("Победил Игрок №1<br>");								
							} else if ($answer > $_GET["userAnswer1"]) {
								echo("Игрок №1 ввел маленькое число!<br>");
							} else if ($answer < $_GET["userAnswer1"]) {
								echo("Игрок №1 ввел большое число!<br>");
							}  else {
								echo("Игрок №1: некорректные данные!<br>");
							}
							if ($answer == $_GET["userAnswer2"]) {
								echo("Победил Игрок №2<br>");								
							} else if ($answer > $_GET["userAnswer2"]) {
								echo("Игрок №2 ввел маленькое число!<br>");
							} else if ($answer < $_GET["userAnswer2"]) {
								echo("Игрок №2 ввел большое число!<br>");
							}  else {
								echo("Игрок №2: некорректные данные!<br>");
							}
						} 
						
					?>
					<form method="GET">
						<p id="info">Отгадайте число с 0 до 100!</p>
						<p>Игрок №1:</p><input type="text" name="userAnswer1">
						<br>
						<p>Игрок №2:</p><input type="text" name="userAnswer2">
						<br>
						<input type="submit" value="Ответить" name="">
						</form>
													
				</div>
	
			</div>
		</div>
	</div>
</div>
<div class="footer">
		copyright &copy; Alexander Bikmeev
</div>
	
</body>
</html>