	<div class="header">
		<a href="index.php">Главная</a>
		<a href="puzzle.php">Загадки</a>
		<a href="guess.php">Угадайка</a>
		<a href="password_generator.php">Генератор паролей</a>
	</div>